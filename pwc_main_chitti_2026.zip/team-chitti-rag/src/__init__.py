"""
Team 'COLLEGE OF COMMERCE, ARTS & SCIENCE' RAG - Main Package
A modular RAG system supporting online, local, and hybrid modes.
"""

__version__ = "1.0.0"
__author__ = "Sumit - College of Commerce, Arts & Science Bihar"